package com.example.scientificcalculator;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.lang.Math;
import static java.lang.Math.sqrt;
import static java.lang.String.*;

public class MainActivity extends AppCompatActivity {
    TextView result;
    double num1,num2,answer;
    char c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        result = (TextView)findViewById(R.id.tv1);
    }


    public void One(View view){
        String s = result.getText().toString();
        result.setText(s+1);
    }


    public void Two(View view){
        String s = result.getText().toString();
        result.setText(s+2);
    }


    public void Three(View view){
        String s = result.getText().toString();
        result.setText(s+3);
    }


    public void Four(View view){
        String s = result.getText().toString();
        result.setText(s+4);
    }


    public void Five(View view){
        String s = result.getText().toString();
        result.setText(s+5);
    }


    public void Six(View view){
        String s = result.getText().toString();
        result.setText(s+6);
    }


    public void Seven(View view){
        String s = result.getText().toString();
        result.setText(s+7);
    }


    public void Eight(View view){
        String s = result.getText().toString();
        result.setText(s+8);
    }


    public void Nine(View view){
        String s = result.getText().toString();
        result.setText(s+9);
    }


    public void Zero(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            result.setText(s + 0);
        }
    }


    public void Point(View view){
        String s = result.getText().toString();
        int i,flag=0;
        for (i=0;i<s.length();i++)
        {
            if(s.charAt(i)== '.')
            {
                flag++;
            }
        }
        if(flag == 0)
        {
            if (s.length()==0)
            {
                result.setText(s+0+'.');
            }
            else
                result.setText(s+'.');
        }
    }


    public void Clear(View view){
        result.setText("");
    }


    public void Back(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            s = s.substring(0,s.length()-1);
            result.setText(s);
        }
    }


    public void Summation(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '+';
        }
    }


    public void Subtraction(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '-';
        }
    }


    public void Multiplication(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '*';
        }
    }


    public void Division(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '/';
        }
    }


    public void Percent(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '%';
        }
    }


    public void Equal(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num2 = Double.parseDouble(s);
            if (c =='+'){
                answer = num1+num2;
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }

            if (c =='-'){
                answer = num1-num2;
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }
            if (c =='*'){
                answer = num1*num2;
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }
            if (c =='/'){
                answer = num1/num2;
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }
            if (c =='%'){
                answer = (num1*num2 /100);
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }
            if (c =='^'){
                double ans = 1;
                for (int i=0;i<num2;i++){
                    ans *= num1;
                }
                answer = ans;
                s = valueOf(answer);
                result.setText(s);
                c = '0';
            }
        }

    }


    public void Square(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            answer = num1*num1;
            s = valueOf(answer);
            result.setText(s);
        }
    }

    public void SqMulty(View view){
        String s = result.getText().toString();
        int i;
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            result.setText("");
            c = '^';
        }
    }


    public void SqRoot(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            answer = sqrt(num1);
            s = valueOf(answer);
            result.setText(s);
        }
    }


    public void Factorial(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            double i,fact=1;
            for (i=1;i<=num1;i++)
            {
                fact*=i;
            }
            answer = fact;
            s = valueOf(answer);
            result.setText(s);
        }
    }


    public void PI(View view){
        String s ;
        double pi = 3.1416;
        s = valueOf(pi);
        result.setText(s);
    }


    public void Sin(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            num2 = Math.toRadians(num1);
            answer = Math.sin(num2);
            s = valueOf(answer);
            result.setText(s);
        }
    }


    public void Cos(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            num2 = Math.toRadians(num1);
            answer = Math.cos(num2);
            s = valueOf(answer);
            result.setText(s);
        }
    }


    public void Tan(View view){
        String s = result.getText().toString();
        if (s.length()!=0) {
            num1 = Double.parseDouble(s);
            num2 = Math.toRadians(num1);
            answer = Math.tan(num2);
            s = valueOf(answer);
            result.setText(s);
        }
    }
}